/*************************************
 * Lab 5 Ex4
 * Name:
 * Student No:
 * Lab Group:
 *************************************
 Warning: Make sure your code works on
 lab machine (Linux on x86)
 *************************************/

#include "my_stdio.h"

int my_fflush(MY_FILE *stream) {
	return 0;
}

int my_fseek(MY_FILE *stream, long offset, int whence) {
	return 0;
}